import java.util.Scanner;

public class SumOfDigits {
    // Recursive method to compute sum of digits
    public static int sumOfNumbers(int value) {
        // Base case: If the number is 0, return 0
        if (value == 0) {
            return 0;
        }
        // Recursive case: Extract last digit and add it to the recursive call result
        return (value % 10) + sumOfNumbers(value / 10);
    }

    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a number
        System.out.print("Enter a number: ");
        int number = scanner.nextInt(); // Read user input

        // Compute the sum of digits using recursion
        int sum = sumOfNumbers(number);

        // Display the result
        System.out.println("The sum of " + number + " = " + sum + " using recursion");

        // Close the scanner
        scanner.close();
    }
}